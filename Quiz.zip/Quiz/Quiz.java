import java.util.ArrayList;
import java.util.Scanner;

public class Quiz {

    ArrayList<Question> questions = new ArrayList<>();
    int score = 0;

    public Quiz() {

        questions.add(new Question(
                "Which language is platform independent?",
                "C",
                "Java",
                "Python",
                "C++",
                'B'));

        questions.add(new Question(
                "Which keyword is used to inherit a class?",
                "extends",
                "implements",
                "super",
                "this",
                'A'));

        questions.add(new Question(
                "Which method is the entry point of Java?",
                "start()",
                "init()",
                "main()",
                "run()",
                'C'));

        questions.add(new Question(
                "Which package contains Scanner class?",
                "java.io",
                "java.util",
                "java.lang",
                "java.sql",
                'B'));

        questions.add(new Question(
                "Which symbol is used to end a Java statement?",
                ":",
                ",",
                ";",
                ".",
                'C'));
    }

    public void startQuiz() {

        Scanner sc = new Scanner(System.in);

        for (int i = 0; i < questions.size(); i++) {

            System.out.println("\n--------------------------------");
            System.out.println("Question " + (i + 1));
            System.out.println("--------------------------------");

            Question q = questions.get(i);
            q.displayQuestion();

            System.out.print("Enter your answer (A/B/C/D): ");
            char userAnswer = Character.toUpperCase(sc.next().charAt(0));

            if (userAnswer == q.answer) {
                System.out.println("Correct!");
                score++;
            } else {
                System.out.println("Wrong!");
                System.out.println("Correct Answer : " + q.answer);
            }
        }

        showResult();
    }

    public void showResult() {

        int total = questions.size();
        int wrong = total - score;
        double percentage = (score * 100.0) / total;

        System.out.println("\n===============================");
        System.out.println("        QUIZ RESULT");
        System.out.println("===============================");
        System.out.println("Total Questions : " + total);
        System.out.println("Correct Answers : " + score);
        System.out.println("Wrong Answers   : " + wrong);
        System.out.printf("Percentage      : %.2f%%\n", percentage);

        if (percentage >= 80) {
            System.out.println("Grade : Excellent");
        } else if (percentage >= 60) {
            System.out.println("Grade : Good");
        } else if (percentage >= 40) {
            System.out.println("Grade : Average");
        } else {
            System.out.println("Grade : Better Luck Next Time");
        }
    }
}