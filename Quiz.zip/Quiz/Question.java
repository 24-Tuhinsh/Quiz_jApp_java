public class Question {

    String question;
    String optionA;
    String optionB;
    String optionC;
    String optionD;
    char answer;

    public Question(String question, String optionA, String optionB,
                    String optionC, String optionD, char answer) {

        this.question = question;
        this.optionA = optionA;
        this.optionB = optionB;
        this.optionC = optionC;
        this.optionD = optionD;
        this.answer = Character.toUpperCase(answer);
    }

    public void displayQuestion() {
        System.out.println(question);
        System.out.println("A. " + optionA);
        System.out.println("B. " + optionB);
        System.out.println("C. " + optionC);
        System.out.println("D. " + optionD);
    }
}